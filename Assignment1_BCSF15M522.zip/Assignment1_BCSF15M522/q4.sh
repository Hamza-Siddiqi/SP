if [ $# = 0 ]
then
echo "Invalid ! No filename enter"
exit 0
elif [ $# -gt 1 ]
then
echo "Invalid ! more than 1 filename enter"
exit 0
fi
if [ ! -f $1 ]
then
echo "$1 is not a file"
exit 0
fi
sort $1 | uniq | tee f2

