islower()
{
	echo "***After converting****"
	#string="Hello world"
	var=${str,,}
	echo $var
}

echo "enter any string"
read str


isroot()
{
	if [ $(id -u) = 0 ]
	then
	#echo "true"
	return 0
	exit 0
	elif [ $(id -u) -ne 0 ]
	then
	#echo "false"
	return 1
	exit 0
	fi

}


Isuser()
{
	echo "enter username"
	read user

	var=`cat /etc/passwd | grep -w "$user"`
	if [ $var ]
	then
		return 0

	elif [ -z $var ]
	then
		return 1
	fi
}

islower str
isroot

if [ $? = 0 ]
then
	echo "true"
elif [ $? != 0 ]
then
	echo "false"
fi


if Isuser
then
	echo "true"
else
	echo "false"
fi
