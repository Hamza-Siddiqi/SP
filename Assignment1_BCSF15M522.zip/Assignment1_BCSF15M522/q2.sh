if [ $# = 0 ]
then
echo "Invalid !No filename entered"
exit 0
elif [ $# -gt 1 ]
then
echo "Invalid ! More than 1 filename entered"
exit 0
elif [ ! -f $1 ]
then
echo "File not exist"
exit 0

fi

`sed '1d ; n; d' $1 > evenfile`
`sed 'n; d' $1 > oddfile`
